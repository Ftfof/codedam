#include <device.h>
#include <Timer2.h>
#include <delay.h>
#include <STC15F2K60S2.H>
#include <intrins.h>
#include <system.h>
#include <Smg.h>

U8 display_mode;
U8 uln_mode;


#define KEY_No 0
#define KEY_Down 1
#define KEY_Up 2  
#define DISPLAY_no 0		
#define DISPLAY_uln 1
#define DISPLAY_led 2
HexToBin uln_ctrl, led_ctrl;

// ���������ر���
#define MAIN_INTERFACE 0
#define LIGHT_INTERFACE 1
#define CURTAIN_INTERFACE 2
#define LED_INTERFACE 3
U8 current_interface = MAIN_INTERFACE;

// ����ֵ���壨���� S4��S5��S6��S7 �ֱ��Ӧ����ֵ 4��5��6��7��
#define KEY_S4 4
#define KEY_S5 5
#define KEY_S6 6
#define KEY_S7 7

// ϵͳ��ʼ��
void vSystem_init()
{
    uln_ctrl.hex = 0;
    led_ctrl.hex = 0;
    vDevice_ctrl(0xa0, uln_ctrl.hex);
    vDevice_ctrl(0x80, ~led_ctrl.hex);
}

// ��ȡ��������
U8 uBTN_Read(void)
{
    static U8 key_state;
    U8 key_io, key_v = 0;
    key_io = P3 & 0x0f;

    switch (key_state)
    {
        case KEY_No:
            if (key_io != 0x0f)
                key_state = KEY_Down;
            break;
        case KEY_Down:
            if (key_io != 0x0f)
            {
                if (key_io == 0x0e) key_v = 7;
                if (key_io == 0x0d) key_v = 6;
                if (key_io == 0x0b) key_v = 5;
                if (key_io == 0x07) key_v = 4;
                key_state = KEY_Up;
            }
            else
                key_state = KEY_No;
            break;
        case KEY_Up:
            if (key_io == 0x0f) key_state = KEY_No;
            break;
    }
    return key_v;
}

U8 cnt_BTN;
U8 num_S4 = 0;
U8 key_val = 0;

// ��������
U8 smg_code[] = {
    // 0    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F
    0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71,
    //black  -     H    J    K    L    N    o   P    U     t    G    Q    r   M    y
    0x00, 0x40, 0x76, 0x1E, 0x70, 0x38, 0x37, 0x5C, 0x73, 0x3E, 0x78, 0x3d, 0x67, 0x50, 0x37, 0x6e
}; // ���� 0-9 hello        

// ����ܴ�������
void vSmg_process()
{
    switch (current_interface)
    {
        case MAIN_INTERFACE:
            // ��ʾ "-HELLO--"
            smg_buf[0] = smg_code[16]; // ' '
            smg_buf[1] = smg_code[18]; // 'H'
            smg_buf[2] = smg_code[14]; // 'E'
            smg_buf[3] = smg_code[21]; // 'L'
            smg_buf[4] = smg_code[21]; // 'L'
            smg_buf[5] = smg_code[0]; //  'O'
            smg_buf[6] = smg_code[16]; // ' '
            smg_buf[7] = smg_code[16]; //  ' '
            break;

        case LIGHT_INTERFACE:
            // ��ʾ "-LIGHT-"
            smg_buf[0] = smg_code[17]; // '-'
            smg_buf[1] = smg_code[7];  // 'L'
            smg_buf[2] = smg_code[8];  // 'I'
            smg_buf[3] = smg_code[4];  // 'G'
            smg_buf[4] = smg_code[14]; // 'H'
            smg_buf[5] = smg_code[11]; // 'T'
            smg_buf[6] = smg_code[17]; // '-'
            smg_buf[7] = smg_code[17]; // '-'
            break;

        case CURTAIN_INTERFACE:
            // ��ʾ "CURTAIN"
            smg_buf[0] = smg_code[2];  // 'C'
            smg_buf[1] = smg_code[20]; // 'U'
            smg_buf[2] = smg_code[17]; // 'R'
            smg_buf[3] = smg_code[18]; // 'T'
            smg_buf[4] = smg_code[4];  // 'A'
            smg_buf[5] = smg_code[11]; // 'I'
            smg_buf[6] = smg_code[14]; // 'N'
            smg_buf[7] = smg_code[17]; // '-'
            break;
				case LED_INTERFACE:
            // ��ʾ "LED"
            smg_buf[0] = smg_code[21]; // ' '
            smg_buf[1] = smg_code[21]; // 'H'
            smg_buf[2] = smg_code[21]; // 'E'
            smg_buf[3] = smg_code[21]; // 'L'
            smg_buf[4] = smg_code[21]; // 'L'
            smg_buf[5] = smg_code[21]; //  'O'
            smg_buf[6] = smg_code[21]; // ' '
            smg_buf[7] = smg_code[21]; //  ' '
            break;
    }
}		


void vBTN_process()
{
    if (cnt_BTN >= 10)
    {
        cnt_BTN = 0;
        key_val = uBTN_Read();

        // �л������߼�����ͨ�� S4 ������
        if (key_val == KEY_S4)
        {
            if (current_interface == MAIN_INTERFACE)
            {
                // �������水�� S4��������һ������
                current_interface = LIGHT_INTERFACE;
            }
            else if (current_interface == LIGHT_INTERFACE)
            {
                // ���������ƽ��水�� S4�����봰�����ƽ���
                current_interface = CURTAIN_INTERFACE;
            }
            
						else if (current_interface == CURTAIN_INTERFACE)
            {
                // �ڴ������ƽ��水�� S4������������
                current_interface = LED_INTERFACE;
            }
						else if (current_interface == LED_INTERFACE)
            {
                // �ڴ������ƽ��水�� S4������������
                current_interface = MAIN_INTERFACE;
            }
        }

        // ���������߼���ͨ�� S5 ������
        if (current_interface == LIGHT_INTERFACE)
        {
            if (key_val == KEY_S5)
            {
                uln_ctrl.b.b4 = !uln_ctrl.b.b4; // �л�����״̬
                vDevice_ctrl(0xa0, uln_ctrl.hex);
            }
        }

        // ���������߼���ͨ�� S6 ������
        if (current_interface == CURTAIN_INTERFACE)
        {
            if (key_val == KEY_S6)
            {
                uln_ctrl.b.b6 = !uln_ctrl.b.b6; // �л�����״̬
                vDevice_ctrl(0xa0, uln_ctrl.hex);
            }
        }

        if (current_interface == LED_INTERFACE)
        {
            if (key_val == KEY_S7)
            {
//							vSystem_Init();
//               vDevice_ctrl(0x80,0x3a);
							led_ctrl.hex = ~led_ctrl.hex; // �л�����״̬
                vDevice_ctrl(0x80, led_ctrl.hex);
	
            }
        }
    }
}

// ������
void main()
{
    vSystem_init();
    vTimer2_Init();

    while (1)
    {
        vSmg_process();
        vBTN_process();
    }
}

// �жϷ���
void vTimer2_ISR() interrupt 12
{
    cnt_BTN++;
    vSmg_display();
}