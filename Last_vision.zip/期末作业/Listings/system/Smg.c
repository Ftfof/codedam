#include <Smg.h>

#include <system.h>
#include <device.h>

U8 smg_buf[8];
void vSmg_display()
{	
	static U8 i;
vDevice_ctrl(0xc0,0x00);
vDevice_ctrl(0xE0,~smg_buf[i]);//��ѡ
vDevice_ctrl(0xc0,0x01<<i);//λѡ
	i++;
	if(i==8)
		i=0;

}//�������ʾ����