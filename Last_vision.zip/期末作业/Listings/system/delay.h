#ifndef __DELAY_H_
#define __DELAY_H_
#include <intrins.h>
#include <system.h>
void Delay10us(unsigned int us);
void Delay1us(unsigned int us);
void Delay1ms(unsigned int ms);
void Delay100us(unsigned int us);
#endif
 