#ifndef __SYSTEM_H_
#define __SYSTEM_H_
typedef unsigned char U8;
typedef char S8;
typedef unsigned int U16;
typedef int S16;
#include <intrins.h>
#include <device.h>
#include <Smg.h>
#include <Timer2.h>

typedef struct
{
U8 b0:1;
U8 b1:1;
U8 b2:1;
U8 b3:1;
U8 b4:1;
U8 b5:1;
U8 b6:1;
U8 b7:1;
}
BIST;
typedef union
{

U8 hex;
BIST b;}
HexToBin;//��������������
#endif