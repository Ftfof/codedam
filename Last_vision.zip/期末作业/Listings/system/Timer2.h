#ifndef __TIMER2_H_
#define __TIMER2_H_
#include <intrins.h>
#include <system.h>
void vTimer2_Init(void)	;
	#endif