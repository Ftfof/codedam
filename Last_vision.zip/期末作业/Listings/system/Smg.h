#ifndef __SMG_H_
#define __SMG_H_

#include <system.h>
extern U8 smg_buf[];
void vSmg_display();

	#endif