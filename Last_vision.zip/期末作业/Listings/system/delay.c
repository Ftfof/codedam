	#include <delay.h>
#include <STC15F2K60S2.H>
#include <intrins.h>
	//??100us
	void Delay100us(unsigned int us)		//@11.0592MHz
{
	unsigned char i, j;
unsigned int c;
	for(c=0;c<us;c++)
	{
	_nop_();
	_nop_();
	i = 2;
	j = 15;
	do
	{
		while (--j);
	} while (--i);
}}
//??10us
void Delay10us(unsigned int us)		//@11.0592MHz
{
	unsigned char i;
unsigned int c;
	for(c=0;c<us;c++)
	{
	_nop_();
	i = 25;
	while (--i);
}
}

//??1ms
void Delay1ms(unsigned int ms)		//@12.000MHz
{
	unsigned char i, j;
unsigned int c;
	for(c=0;c<ms;c++)
	{
	i = 12;
	j = 169;
	do
	{
		while (--j);
	} while (--i);
}}
void Delay1us(unsigned int us)		//@11.0592MHz
{unsigned int c;
	for(c=0;c<us;c++)
	{
	_nop_();
	_nop_();
	_nop_();
}

}