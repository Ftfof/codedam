#include <device.h>
#include <STC15F2K60S2.H>
//??????

   void vDevice_ctrl(unsigned char P2data,unsigned char P0data)
	{P0=P0data;
		P2=P2data;
		P2=0x00;}
