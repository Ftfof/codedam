#ifndef __DEVICE_H_
#define __DEVICE_H_
#include <system.h>
 void vDevice_ctrl(unsigned char P2data,unsigned char P0data);


#endif